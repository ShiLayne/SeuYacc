#include "LrTable.h"
#include <iostream>
using namespace std;
int main()
{
	vector<string> tokens;
	tokens.push_back("a");
	tokens.push_back("b");
	tokens.push_back("DOT");
	tokens.push_back("c");
	contextTb Tbl(tokens);
	Tbl.insert("program", "declarations");
	Tbl.insert("declarations", "declaration	declarations");
	Tbl.insert("declarations", "declaration");
	Tbl.insert("declaration", "a	DOT	c");
	Tbl.updateFirstMap();
	LrTable A(Tbl);
}